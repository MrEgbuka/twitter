const express = require('express');
const app = express();
const port = 3000;

//Loads the handlebars module
const handlebars = require('express-handlebars');

const apiCall = () => {
    return [
        {
            rowKey: '1',
            PurchaseAmount: 'First response value'
        },
        {
            rowKey: '2',
            PurchaseAmount: 'Second response value'
        },
        {
            rowKey: '3',
            PurchaseAmount: 'Third response value'
        },
        {
            rowKey: '4',
            PurchaseAmount: 'Fourth response value'
        }
    ];
}

// Configure handlebars as view engine
app.set('view engine', 'handlebars');
app.engine('handlebars', handlebars.engine({ defaultLayout: 'main' }));

// Middleware
app.use(express.static('public'))

// Serve Respones
app.get('/', async (req, res) => {
    const vals = apiCall();

    res.render('main', { layout : 'index', data: vals });
});

app.listen(port, () => console.log(`App listening to port ${port}`));